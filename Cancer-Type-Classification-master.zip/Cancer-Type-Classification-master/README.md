# Cancer-Type-Classification
Learn how to classify types of tumours using Random Forest Classifier.
